declare function safeArrayConcat<T = unknown>(item: T | T[], ...items: (T | T[])[]): T[];

export = safeArrayConcat;
