import type { DefaultColors } from './types/generated/colors'
declare const colors: DefaultColors
export = colors
