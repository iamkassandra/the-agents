module.exports = require('./dist/babel').default
