module.exports = {
  loader: require.resolve('./dist/webpack')
}
