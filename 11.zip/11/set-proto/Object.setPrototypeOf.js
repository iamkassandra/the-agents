'use strict';

var $Object = require('es-object-atoms');

/** @type {import('./Object.setPrototypeOf')} */
module.exports = $Object.setPrototypeOf || null;
