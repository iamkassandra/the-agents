'use strict';

/** @type {import('./es2015')} */
module.exports = require('./es2015');
