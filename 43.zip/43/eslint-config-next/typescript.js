module.exports = {
  extends: ['plugin:@typescript-eslint/recommended'],
}
