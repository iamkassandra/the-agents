const {
  parse,
  parseForESLint,
} = require('next/dist/compiled/babel/eslint-parser')

module.exports = {
  parse,
  parseForESLint,
}
