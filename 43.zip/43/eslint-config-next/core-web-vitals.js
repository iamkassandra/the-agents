module.exports = {
  extends: [require.resolve('.'), 'plugin:@next/next/core-web-vitals'],
}
