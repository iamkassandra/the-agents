declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=no-unused-class-component-methods.d.ts.map