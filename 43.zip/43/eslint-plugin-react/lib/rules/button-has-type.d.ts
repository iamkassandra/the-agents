declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=button-has-type.d.ts.map