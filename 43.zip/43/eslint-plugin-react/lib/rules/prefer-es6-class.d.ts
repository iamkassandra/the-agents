declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=prefer-es6-class.d.ts.map