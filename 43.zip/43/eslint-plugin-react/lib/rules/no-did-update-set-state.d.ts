declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=no-did-update-set-state.d.ts.map