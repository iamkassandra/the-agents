declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=no-this-in-sfc.d.ts.map