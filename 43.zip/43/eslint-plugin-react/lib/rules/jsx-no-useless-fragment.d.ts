declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=jsx-no-useless-fragment.d.ts.map