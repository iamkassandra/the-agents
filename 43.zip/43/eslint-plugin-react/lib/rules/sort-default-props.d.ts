declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=sort-default-props.d.ts.map