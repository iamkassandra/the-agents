declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=no-did-mount-set-state.d.ts.map