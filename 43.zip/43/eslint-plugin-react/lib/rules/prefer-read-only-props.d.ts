declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=prefer-read-only-props.d.ts.map