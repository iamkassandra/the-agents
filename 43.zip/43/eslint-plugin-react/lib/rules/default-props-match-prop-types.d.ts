declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=default-props-match-prop-types.d.ts.map