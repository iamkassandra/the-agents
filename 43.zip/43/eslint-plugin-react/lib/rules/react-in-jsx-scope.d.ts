declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=react-in-jsx-scope.d.ts.map