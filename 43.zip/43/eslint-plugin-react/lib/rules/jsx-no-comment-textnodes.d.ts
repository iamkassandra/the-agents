declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=jsx-no-comment-textnodes.d.ts.map