declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=style-prop-object.d.ts.map