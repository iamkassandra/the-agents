declare const _exports: import('eslint').Rule.RuleModule;
export = _exports;
//# sourceMappingURL=forward-ref-uses-ref.d.ts.map