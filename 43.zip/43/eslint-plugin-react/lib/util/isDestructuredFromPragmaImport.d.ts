declare function _exports(context: Context, node: ASTNode, variable: string, ...args: any[]): boolean;
export = _exports;
//# sourceMappingURL=isDestructuredFromPragmaImport.d.ts.map