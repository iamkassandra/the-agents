export = log;
/**
 * Logs out a message if there is no format option set.
 * @param {string} message - Message to log.
 */
declare function log(message: string): void;
//# sourceMappingURL=log.d.ts.map