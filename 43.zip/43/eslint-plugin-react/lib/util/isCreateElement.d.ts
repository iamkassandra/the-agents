declare function _exports(context: Context, node: ASTNode): boolean;
export = _exports;
//# sourceMappingURL=isCreateElement.d.ts.map