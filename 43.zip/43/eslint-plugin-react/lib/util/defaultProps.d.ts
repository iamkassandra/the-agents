declare function _exports(context: any, components: any, utils: any): {
    MemberExpression(node: any): void;
    MethodDefinition(node: any): void;
    'ClassProperty, PropertyDefinition'(node: any): void;
    ObjectExpression(node: any): void;
};
export = _exports;
//# sourceMappingURL=defaultProps.d.ts.map