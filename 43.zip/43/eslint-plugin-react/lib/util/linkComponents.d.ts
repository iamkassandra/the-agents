export function getFormComponents(context: any): Map<any, any>;
export function getLinkComponents(context: any): Map<any, any>;
//# sourceMappingURL=linkComponents.d.ts.map