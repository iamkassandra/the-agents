declare function _exports(node: ASTNode): boolean;
export = _exports;
//# sourceMappingURL=isCreateContext.d.ts.map