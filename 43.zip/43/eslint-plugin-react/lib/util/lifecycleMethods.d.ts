declare const _exports: {
    instance: string[];
    static: string[];
};
export = _exports;
//# sourceMappingURL=lifecycleMethods.d.ts.map