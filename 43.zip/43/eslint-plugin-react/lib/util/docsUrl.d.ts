export = docsUrl;
declare function docsUrl(ruleName: any): string;
//# sourceMappingURL=docsUrl.d.ts.map