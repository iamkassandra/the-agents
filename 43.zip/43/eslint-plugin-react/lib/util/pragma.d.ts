/**
 * @param {Context} context
 * @returns {string}
 */
export function getCreateClassFromContext(context: Context): string;
/**
 * @param {Context} context
 * @returns {string}
 */
export function getFragmentFromContext(context: Context): string;
/**
 * @param {Context} context
 * @returns {string}
 */
export function getFromContext(context: Context): string;
//# sourceMappingURL=pragma.d.ts.map