const neostandard = require('neostandard')

module.exports = [
  ...neostandard(),
  {
    name: 'node-0.10-compatibility',
    rules: {
      'object-shorthand': 'off' // Disable ES6 object shorthand for Node.js 0.10 compatibility
    }
  }
]
