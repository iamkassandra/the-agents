declare function pkgUp(opts?: { cwd?: string }): string | null;

export default pkgUp;
