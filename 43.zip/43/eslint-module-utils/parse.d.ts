import { AST, Rule } from 'eslint';



declare function parse(
    path: string,
    content: string,
    context: Rule.RuleContext
): AST.Program | null | undefined;

export default parse;
