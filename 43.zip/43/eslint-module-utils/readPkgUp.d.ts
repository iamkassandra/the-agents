import pkgUp from './pkgUp';

declare function readPkgUp(opts?: Parameters<typeof pkgUp>[0]): {} | { pkg: string, path: string };

export default readPkgUp;
