# Security Policy

## Supported Versions

Latest major/minor version is supported only for security updates.

## Reporting a Vulnerability

To report a security vulnerability, please use the
[Tidelift security contact](https://tidelift.com/security).
Tidelift will coordinate the fix and disclosure.
