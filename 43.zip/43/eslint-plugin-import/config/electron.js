/**
 * Default settings for Electron applications.
 */
module.exports = {
  settings: {
    'import/core-modules': ['electron'],
  },
};
